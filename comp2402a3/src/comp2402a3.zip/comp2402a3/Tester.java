package comp2402a3;

public class Tester {
	
	
	private static Interval<Integer> createPoint(int i, int j){
		return new Interval<Integer>(i,j);
	}
	public static boolean testPart1(IntervalSet<Integer> dis) {
		// Your code goes here
		return false;
	}

	public static boolean testPart2(IntervalSet<Integer> dis) {
		for(int i = 0 ; i < 20 ; i+=1 ){
			dis.add(createPoint(i, (i+1)));
			System.out.println(dis);
		}
		
		dis.add(createPoint(-1,5));
		dis.add(createPoint(-2,3));
		dis.add(createPoint(-2,-2));
		dis.add(createPoint(20,20));

		System.out.println(dis);
		//z1 is indeed bigger than z
		return true;
	}
}

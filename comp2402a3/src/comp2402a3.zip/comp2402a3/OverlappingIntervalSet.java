package comp2402a3;
import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;
/**
 * This class implements the IntervalSet interface for storing a set of
 * intervals, which may or may not be disjoint.
 *
 * @author morin
 *
 * @param <K>
 */
public class OverlappingIntervalSet<K extends Comparable<K>> implements IntervalSet<K> {

    SortedSet<Interval<K>> intervals;

    public OverlappingIntervalSet() {
        intervals = new TreeSet<>();
    }
    private Interval<K> createInterval(K i, K j){
    	return new Interval<K>(i,j);
    }
    private SortedSet<Interval<K>> createInstance(SortedSet<Interval<K>> a){
    	return new TreeSet<Interval<K>>(a);
    }
    @Override	
    public boolean add(Interval<K> i) {
    	System.out.println("Adding: "+ i);
    	if(i.getA().compareTo(i.getB()) > 0) return false;
    	Interval<K> j = i;
    	if(!intervals.isEmpty()){
	    	SortedSet<Interval<K>> tail =intervals.tailSet(new Interval<K>(i.getB(), i.getB()));
	    	SortedSet<Interval<K>> head =intervals.headSet(new Interval<K>(i.getA(), i.getA()));
	    	
	    	System.out.println("Tail: "+ tail);
	    	System.out.println("Head: "  + head );
	    	//base cases
	    	if(tail.isEmpty() && head.isEmpty())
	    		intervals.clear();
	    	else if(tail.isEmpty())
	    		intervals = createInstance(head);
	    	
	    	else if(head.isEmpty()){
	    		intervals = createInstance(tail.tailSet(new Interval<K>(i.getB(), i.getB())));
	    	}
	    	
	    	if(!tail.isEmpty()){
	    		if(tail.first().getA().equals(i.getB())){
	    			i = createInterval(i.getA(), tail.first().getB());
	    			intervals.remove(tail.first());
	    		}
	    		else if(tail.first().getA().compareTo(i.getB()) < 0){
	    			i = createInterval(i.getA(), tail.first().getB());
	    			intervals.remove(tail.first());
	    		}
	    	}
	    		
	    	if(!head.isEmpty()){
	    		if(head.last().getB().equals(i.getA())){
	    			i = createInterval(head.last().getA(), i.getB());
	    			intervals.remove(head.last());
	    		}
	    		else if(head.last().getB().compareTo(i.getA()) > 0){
	    			i = createInterval(head.last().getA(), i.getB());
	    			intervals.remove(head.last());
	    		}
	    	}
	    	
    	}
    	intervals.add(i);
    	if(j.getA() == j.getB()) intervals.add(j);
    	return true;
    }
    

    @Override
    public void clear() {
        intervals.clear();
    }

    @Override
    public boolean contains(K x) {
    	return intervals.contains(new Interval<K>(x,x));
    }

    @Override
    public String toString() {
        return intervals.toString();
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        Tester.testPart2(new OverlappingIntervalSet<Integer>());
    }

}
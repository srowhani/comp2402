package comp2402a4;

public class Data {
	public GeometricTreeNode u;
	public int x;
	public int y;

	public Data(GeometricTreeNode u, int x, int y){
		this.u = u;
		this.x = x;
		this.y = y;

	}
	
}
